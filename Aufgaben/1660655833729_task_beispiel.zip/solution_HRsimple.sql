-- HRsimple::
-- Vor- und Nachname, Telefonnummer, Manager und E-Mail aller Mitarbeiter der Manager 100 oder 122, deren Nachname ein e enthält.
SELECT first_name, last_name, phone_number, manager_id, email
FROM hr.employees
WHERE manager_id IN (100, 122)
AND last_name LIKE '%e%';

